<?php
include_once("includes/dbconn.php");
$conn=database_connect();

$id=$_POST["id"];
//$email=$_POST["email"];
//$enroll=$_POST["enroll"];
$tag=$_POST["tag"];
$comp=$_POST["comp"];
$desig=$_POST["desig"];
$desc=$_POST["desc"];
$join=$_POST["join"];
$end=$_POST["end"];

	$selectsql="insert vaa_prof_exp values ($id, '".$comp."', '".$desig."', '".$desc."', '".$join."', '".$end."', '".$tag."')";

	$qget=mysqli_query($conn,$selectsql);

	if(mysqli_affected_rows($conn)>0){
    	$json_out=json_encode(array('error'=>false,'message'=>"Data Inserted"));
	}else{
		$json_out=json_encode(array('error'=>true,'message'=>"Error Occurred"));
	}

	header("Content-Type:application/json");
	echo $json_out;
?>
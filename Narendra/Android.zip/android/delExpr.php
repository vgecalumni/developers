<?php
include_once("includes/dbconn.php");
$conn=database_connect();

$id=$_POST["id"];
$tag=$_POST["tag"];

	$selectsql="delete from vaa_prof_exp where tag='".$tag."' && id=$id";

	$qget=mysqli_query($conn,$selectsql);

	if(mysqli_affected_rows($conn) > 0){
    	        $json_out=json_encode(array('error'=>false,'message'=>"Data Deleted"));
	}else{
		$json_out=json_encode(array('error'=>true,'message'=>"Error Occurred"));
	}

	header("Content-Type:application/json");
	echo $json_out;
?>
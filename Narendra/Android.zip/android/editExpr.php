<?php
include_once("includes/dbconn.php");
$conn=database_connect();

//$email=$_POST["email"];
$id=$_POST["id"];
$tag=$_POST["tag"];
$comp=$_POST["comp"];
$desig=$_POST["desig"];
$desc=$_POST["desc"];
$join=$_POST["join"];
$end=$_POST["end"];

	$selectsql="update vaa_prof_exp set company='".$comp."', desig='".$desig."', description='".$desc."', startingyr='".$join."', endingyr='".$end."'  where tag='".$tag."' && id=$id";

	$qget=mysqli_query($conn,$selectsql);

	if(mysqli_affected_rows($conn) > 0){
    	$json_out=json_encode(array('error'=>false,'message'=>"Data Updated"));
	}else{
		$json_out=json_encode(array('error'=>true,'message'=>mysqli_error($conn)));
	}

	header("Content-Type:application/json");
	echo $json_out;
?>
<?php
include_once("includes/dbconn.php");
$conn=database_connect();
$id=$_POST["id"];

//$enrollNo=$_POST["enroll"];
$firstName=$_POST["fname"];
$middleName=$_POST["mname"];
$lastName=$_POST["lname"];
//$gender=$_POST["gender"];
//$dob=$_POST["dob"];
//$mobile=$_POST["mob"];
$address=$_POST["address"];
$city=$_POST["city"];
$district=$_POST["district"];
$state=$_POST["state"];
$postalcode=$_POST["pincode"];
//$branch=$_POST["branch"];

	$sql="update vaa_prof set firstName='".$firstName."', middleName='".$middleName."', lastName='".$lastName."',address='".$address."',city='".$city."',district='".$district."',state='".$state."', postalcode='".$postalcode."' where id = '".$id."'";
	
	$exe= mysqli_query($conn,$sql);
	
	if(mysqli_affected_rows($conn)>0){
		$json_out=json_encode(array('error'=>false,'message'=>"Data Updated"));
	}else{
		$json_out=json_encode(array('error'=>true,'message'=>mysqli_error($conn)));
	}

header("Content-Type:application/json");
echo $json_out;
?>
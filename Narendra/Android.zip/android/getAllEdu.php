<?php
include_once("includes/dbconn.php");
$conn=database_connect();
$id=$_POST["id"];

	$selectsql="select * from vaa_prof_edu where id=$id";

	$qget=mysqli_query($conn,$selectsql);

	$edus = array(); 

	if(mysqli_num_rows($qget)>0){

		while($res=mysqli_fetch_array($qget,MYSQLI_ASSOC)){ 

        $edu = array(); 
        $edu['degree'] = $res['degree']; 
        $edu['stream']= $res['stream']; 
        $edu['inst'] = $res['institute']; 
        $edu['join'] = $res['startyear']; 
        $edu['end'] = $res['endyear'];
        $edu['tag']=$res['tag'];
        array_push($edus, $edu);

    	}

    	$json_out=json_encode(array('error'=>false,'message'=>"Data Fetched",'data'=>$edus));
	}else{
		$json_out=json_encode(array('error'=>true,'message'=>"No Education Details"));
	}

	header("Content-Type:application/json");
	echo $json_out;

?>
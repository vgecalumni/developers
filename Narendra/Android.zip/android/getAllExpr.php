<?php
include_once("includes/dbconn.php");
$conn=database_connect();
$id=$_POST["id"];

	$selectsql="select * from vaa_prof_exp where id=$id";

	$qget=mysqli_query($conn,$selectsql);

	$edus = array(); 

	if(mysqli_num_rows($qget)>0){

		while($res=mysqli_fetch_array($qget,MYSQLI_ASSOC)){ 

        $edu = array(); 
        $edu['company'] = $res['company']; 
        $edu['desig']= $res['desig']; 
        $edu['desc'] = $res['description']; 
        $edu['join'] = $res['startingyr']; 
        $edu['end'] = $res['endingyr']; 
        $edu['tag'] = $res['tag'];
        array_push($edus, $edu);

    	}

    	$json_out=json_encode(array('error'=>false,'message'=>"Data Fetched",'data'=>$edus));
	}else{
		$json_out=json_encode(array('error'=>true,'message'=>"No Experience Details"));
	}

	header("Content-Type:application/json");
	echo $json_out;

?>
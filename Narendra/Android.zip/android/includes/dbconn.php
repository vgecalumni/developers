<?php
error_reporting(E_ALL);
  function database_connect()
  {
   $DB_SERVER = "localhost";
   $DB_USERNAME = "id3154768_narendra1520";
   $DB_PASSWORD="narendra1520";
   $DB ="id3154768_lpd";
   $conn= mysqli_connect("$DB_SERVER","$DB_USERNAME","$DB_PASSWORD",$DB) or 
          die ("could not connect to mysql");
   if (!$conn) {
   	return false;
   }
   else {
    return $conn;
   }
  }
?>